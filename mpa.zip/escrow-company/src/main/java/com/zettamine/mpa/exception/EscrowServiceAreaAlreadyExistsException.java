package com.zettamine.mpa.exception;

public class EscrowServiceAreaAlreadyExistsException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EscrowServiceAreaAlreadyExistsException(String msg) {
		super(msg);
		
	}
	
		
}
