package com.zettamine.mpa.escrow.service;

public interface EscrowReqLoanProductService {

}
