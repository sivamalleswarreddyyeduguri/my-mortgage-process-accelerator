package com.zettamine.mpa.escrow.dto;

import org.springframework.validation.annotation.Validated;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.zettamine.mpa.escrow.constants.EscrowConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
@Validated
public class EscrowServiceAreaDto {
		
	@NotBlank(message = EscrowConstants.COUNTY_VALIDATION)
    @Pattern(regexp= EscrowConstants.NAMES_REGEX, message = EscrowConstants.INVALID_NAME)
	 private String county;
	
	@NotBlank(message = EscrowConstants.CITY_VALIDATION)
    @Pattern(regexp= EscrowConstants.NAMES_REGEX, message = EscrowConstants.INVALID_NAME)
	 private String city;
	
	@NotBlank(message = EscrowConstants.STATE_VALIDATION)
    @Pattern(regexp= EscrowConstants.NAMES_REGEX, message = EscrowConstants.INVALID_NAME)
	 private String state;
	
	 @NotBlank(message = EscrowConstants.ZIPCODE_VALIDATION)
     @Pattern(regexp= EscrowConstants.ZIPCODE_REGEX, message = EscrowConstants.INVALID_ZIPCODE)
	 private String zipcode;
	 
//	 @JsonProperty(access = Access.WRITE_ONLY)
//	 private EscrowDto escrow;
	 
//	 @JsonProperty(access = Access.WRITE_ONLY)
//	 @NotNull(message = EscrowConstants.ESCROW_ID_VALIDAATION)
//	 private String escoName;
	 
	 @JsonProperty(access = Access.WRITE_ONLY)
	 private EscrowNameDto escrowNameDto;
}
