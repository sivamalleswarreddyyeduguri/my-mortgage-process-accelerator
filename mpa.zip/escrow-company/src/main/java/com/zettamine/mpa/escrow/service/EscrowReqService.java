package com.zettamine.mpa.escrow.service;

public interface EscrowReqService {

}
