package com.zettamine.mpa.escrow.dto;

import lombok.Data;

@Data
public class EscrowReqDto {
	
	private String reqName;
	private String description;
}
