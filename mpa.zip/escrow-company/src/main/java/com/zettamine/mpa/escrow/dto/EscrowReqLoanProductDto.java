package com.zettamine.mpa.escrow.dto;

public class EscrowReqLoanProductDto {
		
}
