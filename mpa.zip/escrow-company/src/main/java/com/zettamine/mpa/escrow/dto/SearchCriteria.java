package com.zettamine.mpa.escrow.dto;

import lombok.Data;

@Data
public class SearchCriteria {
	
	private String name;
	private String state;
	private String city;
	private String zipcode;
	
}
