package com.zettamine.mpa.mapper;

public class EscrowReqMapper {

}
