package com.zettamine.mpa.exception;

public class EscrowAgentAlreadyExistsException extends RuntimeException{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EscrowAgentAlreadyExistsException(String message) {
		super(message);
		
	}
		
	
}
