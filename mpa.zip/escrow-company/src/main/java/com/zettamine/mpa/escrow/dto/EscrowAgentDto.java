package com.zettamine.mpa.escrow.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.zettamine.mpa.escrow.constants.EscrowConstants;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EscrowAgentDto {
	
	@NotBlank(message = EscrowConstants.LICENCE_VALIDATION)
    @Pattern(regexp= EscrowConstants.ESC_LINCENCE_ID_REGEX, message = EscrowConstants.INVALID_ESC_LIENCE_ID)
	private String escrowAgentLicenceId;
	
	@NotBlank(message = EscrowConstants.FIRST_NAME_VALIDATION)
    @Pattern(regexp= EscrowConstants.NAMES_REGEX, message = EscrowConstants.INVALID_NAME)
	private String firstName;
	
	@NotBlank(message = EscrowConstants.LAST_NAME_VALIDATION)
    @Pattern(regexp= EscrowConstants.NAMES_REGEX, message = EscrowConstants.INVALID_NAME)
	private String lastName;
	
	@NotBlank(message = EscrowConstants.EMAIL_VALIDATION)
    @Pattern(regexp= EscrowConstants.EMAIL_REGEX, message = EscrowConstants.INVALID_EMAIL)
	private String email;
	
	@NotBlank(message = EscrowConstants.PHONE_VALIDATION)
    @Pattern(regexp= EscrowConstants.PHONE_REGEX, message = EscrowConstants.INVALID_PHONE_NUMBER)
	private String phone;
	
	@NotNull(message = EscrowConstants.AVGTXV_VALIDATION)
	private Integer avgTxVol;
	private Float txSuccessRate;
	private String escrowSw;
	
	
//	@JsonIgnore
//    private EscrowDto escrow;
	
//	 @NotNull(message = EscrowConstants.ESCROW_ID_VALIDAATION)
	 @JsonProperty(access = Access.WRITE_ONLY)
	 private Integer escoId;
}
