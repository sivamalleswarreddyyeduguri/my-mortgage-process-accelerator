package com.zettamine.mpa.exception;

public class EscrowAlreadyExistsException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public EscrowAlreadyExistsException(String msg) {
		super(msg);
		
	}

	 

}
