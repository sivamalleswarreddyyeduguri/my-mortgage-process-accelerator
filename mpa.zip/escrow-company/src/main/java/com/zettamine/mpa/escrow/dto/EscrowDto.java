 package com.zettamine.mpa.escrow.dto;

import java.util.ArrayList;
import java.util.List;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonProperty.Access;
import com.zettamine.mpa.escrow.constants.EscrowConstants;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class EscrowDto {
	
//	private Integer id;
	
	@NotBlank(message = EscrowConstants.NAME_VALIDATION)
    @Pattern(regexp= EscrowConstants.NAMES_REGEX, message = EscrowConstants.INVALID_NAME)
	private String escoName;
	
	@NotBlank(message = EscrowConstants.ADDRESS_VALIDATION)
	private String address;
	
	@NotBlank(message = EscrowConstants.CITY_VALIDATION)
    @Pattern(regexp= EscrowConstants.NAMES_REGEX, message = EscrowConstants.INVALID_NAME)
	private String city;
	
	@NotBlank(message = EscrowConstants.STATE_VALIDATION)
    @Pattern(regexp= EscrowConstants.NAMES_REGEX, message = EscrowConstants.INVALID_NAME)
	private String state;
	
	@NotBlank(message = EscrowConstants.CITY_VALIDATION)
    @Pattern(regexp= EscrowConstants.ZIPCODE_REGEX, message = EscrowConstants.INVALID_ZIPCODE)
	private String zipcode;
	
	@NotEmpty(message = EscrowConstants.PHONE_VALIDATION)
    @Pattern(regexp= EscrowConstants.PHONE_REGEX, message = EscrowConstants.INVALID_PHONE_NUMBER)
	private String phone;
	
	@NotEmpty(message = EscrowConstants.EMAIL_VALIDATION)
	@Pattern(regexp = EscrowConstants.EMAIL_REGEX, message = EscrowConstants.INVALID_EMAIL)
	private String email;
	
	@NotEmpty(message = EscrowConstants.ESCROW_ACCOUNT_VALIDAATION)
	@Pattern(regexp = EscrowConstants.ACCOUNT_NUMBER_REGEX, message = EscrowConstants.INVALID_ACCOUNT_NUMBER)
	private String inEscrowAcNo;
	
	@NotEmpty(message = EscrowConstants.ESCROW_BANK_NAME_VALIDATION)
	@Pattern(regexp = EscrowConstants.NAMES_REGEX, message = EscrowConstants.INVALID_NAME)
	private String esAcBankName;
	
	
	private Integer esProcessTime;
	
	@JsonProperty(access = Access.WRITE_ONLY)
	@Valid
    private List<EscrowServiceAreaDto> serviceArea = new ArrayList<>();
	
	@JsonProperty(access = Access.WRITE_ONLY)
	@Valid
    private List<EscrowAgentDto> escrowAgent = new ArrayList<>();
       
              
}
