package com.zettamine.mpa.escrow.serviceImpl;

public class EscrowReqLoanProductServiceImpl {

}
