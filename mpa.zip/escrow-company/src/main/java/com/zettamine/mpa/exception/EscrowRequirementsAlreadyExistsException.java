package com.zettamine.mpa.exception;

public class EscrowRequirementsAlreadyExistsException {

}
